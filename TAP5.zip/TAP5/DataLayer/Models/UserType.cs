﻿using System;
using System.Collections.Generic;

namespace DataLayer.Models
{
    // Modelul pentru tipul utilizatorului
    public class UserType
    {
        // Constructor pentru clasa UserType
        public UserType(string name)
        {
            Name = name;
            Users = new List<User>();
        }

        // Proprietatea pentru ID-ul tipului de utilizator
        public Guid Id { get; set; }
        // Proprietatea pentru numele tipului de utilizator
        public string Name { get; set; }

        // Relație one-to-many cu User (un tip de utilizator poate avea mai mulți utilizatori)
        public ICollection<User> Users { get; set; }
    }
}