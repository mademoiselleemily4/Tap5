﻿using System;
using System.Collections.Generic;

namespace DataLayer.Models
{
    // Modelul pentru utilizator
    public class User
    {
        // Constructor pentru clasa User
        public User(string name, string email, string password)
        {
            Name = name;
            Email = email;
            Password = password;
        }

        // Proprietatea pentru ID-ul utilizatorului
        public Guid Id { get; set; }
        // Proprietatea pentru numele utilizatorului
        public string Name { get; set; }
        // Proprietatea pentru adresa de email a utilizatorului
        public string Email { get; set; }
        // Proprietatea pentru parola utilizatorului
        public string Password { get; set; }

        // Proprietate de navigare către UserType (relație one-to-one)
        public UserType Type { get; set; }
    }
}

// Project.cs
using System;
using System.Collections.Generic;

namespace DataLayer.Models
{
    // Modelul pentru proiect
    public class Project
    {
        // Constructor pentru clasa Project
        public Project(string name)
        {
            Name = name;
            Users = new List<User>();
        }

        // Proprietatea pentru ID-ul proiectului
        public Guid Id { get; set; }
        // Proprietatea pentru numele proiectului
        public string Name { get; set; }

        // Relație one-to-many cu User (un proiect poate avea mai mulți utilizatori)
        public ICollection<User> Users { get; set; }
    }
}