﻿using DataLayer.Models;
using Microsoft.EntityFrameworkCore;

namespace DataLayer
{
    // This class represents the database context for interacting with the underlying database.
    // dotnet ef migrations add Initial
    // dotnet ef database update
    public class MyDbContext : DbContext
    {
        // Modified connection string for your environment
        // The connection string should be updated with your actual server details and credentials.
        private readonly string _customConnectionString = @"Server=myServerAddress;Database=myDatabase;User Id=myUsername;Password=myPassword;";

        // DbSet properties for entities
        // These properties represent the tables in the database and allow interaction with the corresponding entities.
        public DbSet<User> Users { get; set; }
        public DbSet<UserType> UserTypes { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            // Configuring the database provider and connection string
            // In this case, SQL Server is used as the database provider.
            optionsBuilder.UseSqlServer(_customConnectionString);
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            // Configuring the relationship between User and UserType entities using Fluent API
            // This establishes a one-to-many relationship between User and UserType entities.
            // Each User belongs to one UserType, while a UserType can have multiple Users.
            builder.Entity<User>()
                .HasOne(f => f.Type)
                .WithMany(c => c.Users)
                .HasForeignKey(f => f.TypeId);
        }
    }
}
