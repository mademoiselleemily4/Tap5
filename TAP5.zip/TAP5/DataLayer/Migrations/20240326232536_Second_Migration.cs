﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace DataLayer.Migrations
{
    // Placeholder migration
    public partial class Second_Migration : Migration
    {
        // Up method defines the operations to be performed when applying the migration
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // No additional operations needed for this migration
        }

        // Down method defines the operations to be performed when reverting the migration
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // No additional operations needed for this migration
        }
    }
}